﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lac;
using Carrote;

namespace UC_Lion
{
   
    public partial class Lion : UserControl
    {
        private LAC lac;
        private int vitesse=10;
        private List<Carotte> CarotteList;
        private Carotte caro;

        public Lion()
        {
            InitializeComponent();

            
        }
        //public void position()
        //{
        //    Random rand = new Random();
        //    Point tmp = new Point(this.Location.X, this.Location.Y);
        //    tmp.X = rand.Next(10, 800);
        //    tmp.Y = rand.Next(10, 500);
        //    this.Location = tmp;
        //}

        public void Grossir(int poid, int speed)
        { this.Width += poid;
            this.Height += poid;
            this.vitesse = speed;
            //Point tmp = new Point(this.Location.X, this.Location.Y);
           // tmp.X += speed;
           // tmp.Y += speed;
        }

        public void maigrir(int poid, int speed)
        {
            this.Width -= poid;
            this.Height -= poid;
            this.vitesse = speed;
        }

        public void boire(int speed)
        {

            this.vitesse = speed;
        }


        public Lion(int X, int Y, int W, int H, LAC lac, List<Carotte> CarotteList)
        {
            InitializeComponent();
            this.CarotteList = CarotteList;

            this.caro = new Carotte();
            this.lac = lac;
        

            X = this.Location.X;
            Y = this.Location.Y;
            W = this.Width;
            H = this.Height;

        }


        public void move(KeyEventArgs e)
        {
            
            if (e.KeyCode == Keys.A)
            {

                this.Location = new Point(this.Location.X - vitesse, this.Location.Y);

            }
            else if (e.KeyCode == Keys.D)
            {
                this.Location = new Point(this.Location.X + vitesse, this.Location.Y);
            }
            else if (e.KeyCode == Keys.W)
            {
                this.Location = new Point(this.Location.X, this.Location.Y - vitesse);
            }
            else if (e.KeyCode == Keys.S)
            {
                this.Location = new Point(this.Location.X, this.Location.Y + vitesse);
            }

            caro = IsCarotteEaten();
            if (caro != null)
            { caro.stat = false;
                caro.Hide();
                maigrir(10, 5);
            }
          

        }


        public Carotte IsCarotteEaten()
        {
            caro = null;
            foreach (Carotte element in CarotteList)

            {
                if (this.Bounds.IntersectsWith(element.Bounds))
                {
                    if (element.stat)

                    { caro = element; }



                }
            }


                return caro;
        }



    }

}
