﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lac
{
    public partial class LAC : UserControl
    { bool spy ; 
        public LAC()
        {
            InitializeComponent();


            Random rand = new Random();
            this.Width = rand.Next(100, 200);
            this.Height = rand.Next(100, 150);
          

            

        }
        public void position()

        {
            Random rand = new Random();
            Point tmp = new Point(this.Location.X, this.Location.Y);
            tmp.X = rand.Next(10, 900);
            tmp.Y = rand.Next(10, 500);
            this.Location = tmp;
        }


        public delegate void Lacdelegate(Object sender, EventArgs e);

        public event Lacdelegate IsEmpty;

        public void Shrink(int soif)
        {
            this.Height -= soif;
            this.Width -= soif;
            // tester le W et le H de lac}
            if (this.Height <= 20 && spy==false)
            {
                spy = true;
                if (IsEmpty != null)
                { IsEmpty(this, new EventArgs());}
                
            }




        }

        private void UC_Lac_Load(object sender, EventArgs e)
        {

        }
    }
}



















