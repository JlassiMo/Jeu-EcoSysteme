﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Carrote
{
    public partial class Carotte: UserControl
    {
        public bool stat;
        public List<Carotte> CarotteList=new List<Carotte>();
        public Carotte()
        {
            InitializeComponent();
            stat = true;
           
        }


       


        public delegate void Carottedelegate(Object sender, EventArgs e);

        public event Carottedelegate IsGone;


        public void IamEaten()
        {
            foreach (Carotte element in CarotteList)
            {
                if (element.stat == false)
                {
                    if (IsGone != null)
                    { IsGone(this, new EventArgs()); }
                }

            }
        }



    }
}
