﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lac;
using Carrote;
using UC_Lion;

namespace UC_Lapin
{
    public partial class Lapin : UserControl
    {
        private bool statuts;
        private int delaisFaim;
        private int delaisSoif;
        private Timer Stat;
        private Timer heartbeat;
        private LAC lac;
        private Carotte caro;
        private List<Carotte> CarotteList= new List<Carotte>();
        private Lion leo;
        private int vitesses ;
        private int courage ;
        public bool active; //still alive;
        

       


        public Lapin()
        {
            InitializeComponent();
            active = true;
           

        }

        public Lapin(int x, int y,int w, int h, int vitesses, int wform,int hform, List<Carotte> CarotteList, LAC lac, Lion leo, int delaisFaim,int delaisSoif)
        {
            InitializeComponent();
           
            this.lac = lac;
            this.leo = leo;
         
            this.vitesses = vitesses;
            vitesses = 10;
            active = true;
            this.CarotteList = CarotteList;
            this.Width = w;
            this.Height = h;
          
            this.courage = 60;
           
            Random alia = new Random();
            this.delaisFaim = delaisFaim;
           
            this.delaisSoif = delaisSoif;
           
            this.Stat = new Timer();
            this.heartbeat = new Timer();
            Stat.Enabled = true;
            Stat.Start();
            caro = new Carotte();
            heartbeat.Enabled = true;
            heartbeat.Start();
            heartbeat.Interval =500;
            Stat.Interval =alia.Next(8000,10000);

            Stat.Tick += Stat_Tick1;
            heartbeat.Tick += Heartbeat_Tick;
            statuts = true;
           


        }




        private void Stat_Tick1(object sender, EventArgs e)
        {
           Stat.Stop();

          


            if (statuts)
            { statuts = false; }
            else { statuts = true; }
            Stat.Start();
        }

        private void Heartbeat_Tick(object sender, EventArgs e)
        {

           
             
            Carotte Carotte = new Carotte();
            if (statuts)
            {


               

                Carotte = FindClosest();
                movealia(Carotte);

                lapinLac();

                heartbeat.Interval = delaisSoif;
             
            }
            else
            {

                
                movealia(lac);

                lapinLac();

                heartbeat.Interval = delaisFaim;
               

            }

          

            // chercher la carotte qui a le stat = true mettre a hide et stat=false
            Carotte = IsCarotteEaten();
            if (Carotte != null)
            {
                Carotte.Hide();
                Carotte.stat = false;
                grossir(1);
            }


         

        }

      
     


        //chercher la carotte la plus proche
        public Carotte FindClosest()
        {
            Carotte caro = new Carotte();

            double Min = double.MaxValue;

            foreach (Carotte element in this.CarotteList)
            {
                if (element.stat)
                {
                    double deltaX = (element.Location.X - this.Location.X);
                    double deltaY = (element.Location.Y - this.Location.Y);

                    double distance = Math.Sqrt(Math.Pow(deltaX, 2) + Math.Pow(deltaY, 2));


                    if (distance <= Min)
                    {
                        Min = distance;
                        caro = element;
                    }

                }
            }

            return caro;
        


        }
        // bouger le lapin vers un objet 
        public void movealia(UserControl objet)
        {

    
            Random alea = new Random();
            vitesses = 5;
            //int step = 5;
            double deltaX = (objet.Location.X - this.Location.X);
            double deltaY = (objet.Location.Y - this.Location.Y);

            double distance = Math.Sqrt(Math.Pow(deltaX, 2) + Math.Pow(deltaY, 2));

            double angle = Math.Atan(deltaY / deltaX);
            if (deltaX < 0 && deltaY > 0)
            {
                angle = angle + Math.PI;

            }
            else if (deltaX < 0 && deltaY < 0)
            {
                angle = angle + Math.PI;

            }
            else if (deltaX > 0 && deltaY < 0)
            {
                angle = angle + 2 * Math.PI;

            }




            this.Location = new Point(Convert.ToInt16(this.Location.X + (distance / vitesses) * Math.Cos(angle)), Convert.ToInt16(this.Location.Y + (distance / vitesses) * Math.Sin(angle)));


            lookforlion();

        }
           

        //lapin prend du poid
        public void grossir(int poid)
        {
            this.Width += poid;
            this.Height += poid;
        }

        //chercher la distance entre le lapin et le lion
        public void lookforlion()
        {
           
            double deltaX = (leo.Location.X - this.Location.X);
            double deltaY = (leo.Location.Y - this.Location.Y);

            double distance = Math.Sqrt(Math.Pow(deltaX, 2) + Math.Pow(deltaY, 2));
         

            if (distance < 100)
            {
            
                 Point tmp = new Point( );
                 tmp.X=  this.Location.X * (-1);
                 tmp.Y = this.Location.Y * (-1);

                if (tmp.X < 0)
                { tmp.X = 0; }
                else if (tmp.X > 1145)
                { tmp.X = 1145; }
                else if (tmp.Y > 710)
                { tmp.Y = 710; }
                else if (tmp.X < 0)
                { tmp.Y = 0; }


                double deltX = (tmp.X - this.Location.X);
                double deltY = (tmp.Y- this.Location.Y);

                double dist = Math.Sqrt(Math.Pow(deltX, 2) + Math.Pow(deltY, 2));
                double angl = Math.Atan(deltY / deltX);
                if (deltX < 0 && deltY > 0)
                {
                    angl = angl + Math.PI;

                }
                else if (deltX < 0 && deltY < 0)
                {
                    angl = angl + Math.PI;

                }
                else if (deltX > 0 && deltY < 0)
                {
                    angl = angl + 2 * Math.PI;

                }






                this.Location = new Point(Convert.ToInt16(this.Location.X + (dist/4) * Math.Cos(angl)), Convert.ToInt16(this.Location.Y + (dist/4) * Math.Sin(angl)));

             
                
            }



        }

        //verifier si une carotte a ete mangé
        public Carotte IsCarotteEaten()
        {
            caro = null;
            foreach (Carotte element in CarotteList)

            {
                if (this.Bounds.IntersectsWith(element.Bounds))
                {
                    if (element.stat==true)

                    { caro = element;
                       
                    }



                }
            }


            return caro;
        }

        // Detection de la indersection entre le lion et le lac

        public void lapinLac()
        {
            if (this.active)
            {
                if (this.Bounds.IntersectsWith(lac.Bounds))


                {
                    lac.Shrink(1);
                }
            }

        }

    }
}
