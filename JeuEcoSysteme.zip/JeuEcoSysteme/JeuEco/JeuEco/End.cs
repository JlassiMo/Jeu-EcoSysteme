﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JeuEco
{
    public partial class End : Form
    {
        public End()
        {
            InitializeComponent();
        }

        private void btnRetour_Click(object sender, EventArgs e)
        {
            //Form1 Form = new Form1();

            //Form.ShowDialog();

            //this.Close();
            //Form.Dispose();
            Application.Exit();
        }
    }
}
