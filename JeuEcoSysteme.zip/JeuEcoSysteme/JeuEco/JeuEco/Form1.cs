﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Carrote;
using UC_Lapin;
using UC_Lion;
using Lac;


namespace JeuEco
{
    public partial class Form1 : Form
    {
        private LAC l;
        private Carotte Carot;

        private List<Carotte> CarotteList;
        private List<Lapin> LapinList;
        private Lapin rabbit;

        private Timer showCarotte;
        private Lion lion;
        int cnt = 0;
        public Form1()
        {
            InitializeComponent();
            InitLac();
            InitListCarotte();
            
            InitLion();

            

            Carot = new Carotte();
            this.showCarotte = new Timer();
            showCarotte.Enabled = true;
            showCarotte.Start();
            showCarotte.Interval = 2000;
            InitLapin();

            showCarotte.Tick += ShowCarotte_Tick;
            l.IsEmpty += L_IsEmpty;
            this.KeyPreview = true;
           EndGame();

        }
        // ecouter l evenement de lac si elle est vide
        private void L_IsEmpty(object sender, EventArgs e)
        {

            End Fin = new End();

            Fin.ShowDialog();
            this.Close();
            this.Hide();
           
         


        }
        //affichage  aliatoire des carotte
        private void ShowCarotte_Tick(object sender, EventArgs e)
        {
            showCarotte.Stop();

            DemoPlaceRandom();
            cnt++;
            if (cnt == 3)
            { 
                InfoJeu.Visible = false;
            }
            showCarotte.Start();
        }

        //initialiser lac
        private void InitLac()
        {

            l = new LAC();

            l.position();
            this.Controls.Add(l);

        }


        //initialisier carotte
        private void InitListCarotte()
        {

            CarotteList = new List<Carotte>();


        }
        //verification de collision des carottes et les placées
        private void DemoPlaceRandom()
        {

            bool place = true;
            Random alea = new Random(DateTime.Now.Millisecond);
            //while (CarotteList.Count < 10)
            //{
            Carot = new Carotte();

            Carot.Width = alea.Next(10, 50);
            Carot.Height = alea.Next(20, 70);


            if (CarotteList.Count <= 0)
            {
                Carot.Location = new Point(alea.Next(900), alea.Next(500));
            }
            else
            {
                place = true;
                Carot.Location = new Point(alea.Next(900), alea.Next(500));

                foreach (Carotte element in CarotteList)
                {
                    if (Carot.Bounds.IntersectsWith(element.Bounds) || Carot.Bounds.IntersectsWith(l.Bounds))
                    {
                        place = false;
                    }
                }
            }

            if (place)
            {
                CarotteList.Add(Carot);
                this.Controls.Add(Carot);
            }

            //}
        }
        //initialisier lion et placer sur le form
        private void InitLion()
        {


            Random rand = new Random();
            lion = new Lion(rand.Next(10, 900), rand.Next(10, 600), rand.Next(20, 60), rand.Next(20, 60), l, CarotteList);


            int cnt = 0;
            while (cnt <= 1)
            {

                Point tmp = new Point(rand.Next(10, 800), rand.Next(10, 600));
                lion.Location = tmp;
                lion.Width = rand.Next(40, 60);
                lion.Height = rand.Next(40, 60);

                cnt = 0;
                foreach (Carotte element in CarotteList)
                {
                    if (lion.Bounds.IntersectsWith(l.Bounds) || lion.Bounds.IntersectsWith(element.Bounds))
                    { cnt = 1; }

                }

                if (cnt == 0)
                {
                    this.Controls.Add(lion);
                    cnt = 2;
                }

            }


        }


        //initialiser lapin
        private void InitLapin()
        {


            bool place = true;
            Random alea = new Random();
            rabbit = new Lapin();
            LapinList = new List<Lapin>();

            while (LapinList.Count < 5)

            {

                rabbit = new Lapin(400, 400, 30, 30, 10, 600, 900, CarotteList, l, lion, alea.Next(300, 500), alea.Next(300, 500));
                if (LapinList.Count <= 0)
                {
                    rabbit.Location = new Point(alea.Next(900), alea.Next(500));
                    rabbit.Width = alea.Next(15, 30);
                    rabbit.Height = alea.Next(15, 30);
                }

                else
                {
                    place = true;
                    rabbit.Location = new Point(alea.Next(900), alea.Next(500));

                    foreach (Lapin element in LapinList)
                    {
                        if (rabbit.Bounds.IntersectsWith(element.Bounds) || rabbit.Bounds.IntersectsWith(l.Bounds))
                        {
                            place = false;
                        }
                    }
                }


                if (place)
                {
                    LapinList.Add(rabbit);
                    this.Controls.Add(rabbit);
                }

            }










        }


        // entendre l evenement de clavier pour bouger le lion

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            lion.move(e);

            IsLapinEaten();

            lionLac();
            if (lion.Width<10)
            {
                End Fin = new End();


                Fin.ShowDialog();
                this.Close();
                this.Hide();
            }



        }



        // verifier si un lapin a ete manger
        public void IsLapinEaten()
        {

            foreach (Lapin element in LapinList)

            {
                if (lion.Bounds.IntersectsWith(element.Bounds))
                {
                    if (element.active == true)

                    {
                        element.Hide();
                        element.active = false;
                        lion.Grossir(5, 10);
                    }



                }
            }
        }

        // verification de la collision entre lion et lac
        public void lionLac()
        {
            if (lion.Bounds.IntersectsWith(l.Bounds))


            {
                l.Shrink(1);
            }
        }


        // finir le jeu
        public void EndGame()
        {
            int dieLap = 0;
            
            foreach (Lapin element in LapinList)
            {
                if (!rabbit.active)
                {
                    dieLap += 1;
                }

            }

            
            if (dieLap == LapinList.Count())
            {

                End Fin = new End();

                
                Fin.ShowDialog();
                this.Close();
                this.Hide();




            }



        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //MessageBox.Show("Jeu EcoSysteme: bouger le Lion avec les touches W = haut, A=gauche, S= bas , D= droite");
        }
    }
}